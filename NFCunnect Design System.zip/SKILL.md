---
name: nfcunnect-design
description: Use this skill to generate well-branded interfaces and assets for NFCunnect, either for production or throwaway prototypes/mocks/etc. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping. NFCunnect is a Hamburg Juniorfirma selling re-writable NFC copper keychains that act as a digital business card ("Let's cunnect"). Brand language is German.
user-invocable: true
---

Read the `README.md` file within this skill, and explore the other available files.

If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. If working on production code, you can copy assets and read the rules here to become an expert in designing with this brand.

If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.

## Quick start
- **Tokens:** import `colors_and_type.css` — copper primary `#E0741A`, warm neutrals, dark "night" surfaces, Montserrat Alternates (display) + Montserrat (UI) + Space Mono (technical), spacing/radii/warm shadows.
- **Assets:** `assets/` — logo lockups, roll-up banner, product photography. Never redraw the spirograph mark; it's a raster asset.
- **Icons:** Lucide-style line icons (see `ui_kits/*/Icon.jsx` for a ready set). No emoji.
- **UI kits:** `ui_kits/website/` (German marketing site) and `ui_kits/digital-card/` (mobile NFC-tap profile). Copy components from these for high-fidelity recreations.
- **Voice:** German, short clear sentences, the "cunnect" pun in headlines, focus on *verbinden / vernetzen / nachhaltig*. Default to German copy.
