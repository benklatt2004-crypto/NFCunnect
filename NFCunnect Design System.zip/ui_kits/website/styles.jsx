// NFCunnect — Marketing website styles → window.wsStyles
window.wsStyles = {
  page: { width: '100%', background: 'var(--ink-50)', overflow: 'hidden' },

  // ---- Nav ----
  nav: { position: 'sticky', top: 0, zIndex: 50, display: 'flex', alignItems: 'center', justifyContent: 'space-between',
    padding: '0 56px', height: 72, background: 'rgba(250,246,242,0.82)', backdropFilter: 'blur(12px)', borderBottom: '1px solid var(--border)' },
  navBrand: { display: 'flex', alignItems: 'center', gap: 10, cursor: 'pointer' },
  navLogo: { height: 30 },
  navLinks: { display: 'flex', gap: 34, alignItems: 'center' },
  navLink: { fontFamily: 'var(--font-sans)', fontSize: 14.5, fontWeight: 500, color: 'var(--fg)', textDecoration: 'none', cursor: 'pointer', background: 'none', border: 'none' },
  navRight: { display: 'flex', alignItems: 'center', gap: 18 },
  cartBtn: { position: 'relative', background: 'none', border: 'none', cursor: 'pointer', display: 'flex', color: 'var(--fg)' },
  cartCount: { position: 'absolute', top: -7, right: -8, background: 'var(--primary)', color: '#fff', fontSize: 10, fontWeight: 700, minWidth: 17, height: 17, borderRadius: 9, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '0 4px' },

  // ---- shared ----
  btnPrimary: { fontFamily: 'var(--font-sans)', fontWeight: 600, fontSize: 14.5, padding: '11px 22px', borderRadius: 'var(--radius-md)', border: 'none', background: 'var(--primary)', color: '#fff', cursor: 'pointer', boxShadow: 'var(--shadow-sm)', transition: 'all .16s cubic-bezier(.22,1,.36,1)' },
  btnSecondary: { fontFamily: 'var(--font-sans)', fontWeight: 600, fontSize: 14.5, padding: '11px 22px', borderRadius: 'var(--radius-md)', border: '1.5px solid var(--copper-300)', background: 'transparent', color: 'var(--copper-700)', cursor: 'pointer' },
  overline: { fontFamily: 'var(--font-sans)', fontWeight: 600, fontSize: 12.5, textTransform: 'uppercase', letterSpacing: '0.18em', color: 'var(--primary)' },
  section: { padding: '96px 56px' },
  sectionInner: { maxWidth: 1120, margin: '0 auto' },
  h2: { fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 40, lineHeight: 1.12, letterSpacing: '-0.02em', color: 'var(--fg)' },

  // ---- Hero ----
  hero: { display: 'grid', gridTemplateColumns: '1.05fr 0.95fr', gap: 56, alignItems: 'center', padding: '84px 56px 96px', maxWidth: 1200, margin: '0 auto' },
  heroH1: { fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 64, lineHeight: 1.02, letterSpacing: '-0.03em', color: 'var(--fg)', marginTop: 18 },
  heroCu: { color: 'var(--primary)' },
  heroSub: { fontSize: 19, lineHeight: 1.6, color: 'var(--fg-muted)', marginTop: 22, maxWidth: '46ch' },
  heroCtas: { display: 'flex', gap: 14, marginTop: 34 },
  heroVisual: { position: 'relative', borderRadius: 'var(--radius-xl)', overflow: 'hidden', aspectRatio: '4/5', background: 'radial-gradient(120% 90% at 60% 20%, #2A1812, #100A07)', boxShadow: 'var(--shadow-lg)', display: 'flex', alignItems: 'center', justifyContent: 'center' },
  heroImg: { width: '100%', height: '100%', objectFit: 'cover' },
  heroTrust: { display: 'flex', gap: 26, marginTop: 38 },
  heroTrustItem: { display: 'flex', alignItems: 'center', gap: 8, fontSize: 13.5, color: 'var(--fg-muted)', fontWeight: 500 },

  // ---- Problem ----
  problem: { background: 'var(--night-800)', color: 'var(--ink-50)' },
  problemQuote: { fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: 34, lineHeight: 1.3, letterSpacing: '-0.01em', maxWidth: '20ch', color: 'var(--ink-50)' },
  problemQuoteHl: { color: 'var(--copper-400)' },
  problemGrid: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 64, alignItems: 'center' },
  problemList: { display: 'flex', flexDirection: 'column', gap: 18 },
  problemItem: { display: 'flex', gap: 14, alignItems: 'flex-start' },
  problemX: { width: 30, height: 30, borderRadius: 8, background: 'rgba(224,116,26,0.16)', display: 'flex', alignItems: 'center', justifyContent: 'center', flex: 'none', marginTop: 1 },
  problemItemText: { fontSize: 15.5, lineHeight: 1.5, color: 'var(--d-fg-muted)' },

  // ---- How it works ----
  steps: { display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 26, marginTop: 52 },
  step: { background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 'var(--radius-lg)', padding: '30px 26px', boxShadow: 'var(--shadow-xs)' },
  stepNum: { fontFamily: 'var(--font-mono)', fontSize: 13, fontWeight: 700, color: 'var(--copper-600)' },
  stepIcon: { width: 52, height: 52, borderRadius: 14, background: 'var(--copper-50)', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '16px 0 18px' },
  stepTitle: { fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 20, color: 'var(--fg)' },
  stepText: { fontSize: 14.5, lineHeight: 1.55, color: 'var(--fg-muted)', marginTop: 8 },

  // ---- Sustainability ----
  sustain: { background: 'linear-gradient(135deg, #FBE3D2 0%, #F6C4A0 100%)' },
  sustainGrid: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 56, alignItems: 'center' },
  statRow: { display: 'flex', gap: 40, marginTop: 32 },
  stat: {},
  statNum: { fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 44, color: 'var(--copper-700)', lineHeight: 1 },
  statLabel: { fontSize: 13.5, color: 'var(--ink-700)', marginTop: 6, fontWeight: 500 },

  // ---- Product ----
  product: { background: 'var(--surface)' },
  productGrid: { display: 'grid', gridTemplateColumns: '0.9fr 1.1fr', gap: 56, alignItems: 'center' },
  productImg: { width: '100%', borderRadius: 'var(--radius-xl)', boxShadow: 'var(--shadow-md)', aspectRatio: '1', objectFit: 'cover' },
  specList: { display: 'flex', flexDirection: 'column', gap: 12, margin: '26px 0' },
  spec: { display: 'flex', alignItems: 'center', gap: 12, fontSize: 15, color: 'var(--fg)' },
  specCheck: { width: 24, height: 24, borderRadius: '50%', background: 'var(--copper-50)', display: 'flex', alignItems: 'center', justifyContent: 'center', flex: 'none' },
  priceRow: { display: 'flex', alignItems: 'center', gap: 18, marginTop: 30 },
  price: { fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 40, color: 'var(--fg)' },
  priceNote: { fontSize: 13, color: 'var(--fg-muted)' },

  // ---- FAQ ----
  faqList: { maxWidth: 760, margin: '44px auto 0', display: 'flex', flexDirection: 'column', gap: 12 },
  faqItem: { background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 'var(--radius-md)', overflow: 'hidden' },
  faqQ: { display: 'flex', alignItems: 'center', justifyContent: 'space-between', width: '100%', padding: '18px 22px', background: 'none', border: 'none', cursor: 'pointer', fontFamily: 'var(--font-sans)', fontWeight: 600, fontSize: 16, color: 'var(--fg)', textAlign: 'left' },
  faqA: { padding: '0 22px 20px', fontSize: 14.5, lineHeight: 1.6, color: 'var(--fg-muted)', maxWidth: '62ch' },

  // ---- Footer ----
  footer: { background: 'var(--night-900)', color: 'var(--ink-50)', padding: '64px 56px 40px' },
  footerInner: { maxWidth: 1120, margin: '0 auto', display: 'grid', gridTemplateColumns: '1.4fr 1fr 1fr', gap: 40 },
  footerLogo: { height: 34, marginBottom: 18 },
  footerText: { fontSize: 13.5, lineHeight: 1.7, color: 'var(--d-fg-muted)', maxWidth: '34ch' },
  footerColTitle: { fontSize: 12, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.14em', color: 'var(--copper-400)', marginBottom: 16 },
  footerLink: { display: 'block', fontSize: 14, color: 'var(--ink-200)', textDecoration: 'none', marginBottom: 11, cursor: 'pointer' },
  footerSocials: { display: 'flex', gap: 12, marginTop: 8 },
  socialBtn: { width: 40, height: 40, borderRadius: 10, border: '1px solid var(--d-border)', background: 'rgba(224,116,26,0.08)', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' },
  footerBottom: { maxWidth: 1120, margin: '44px auto 0', paddingTop: 24, borderTop: '1px solid rgba(255,255,255,0.08)', display: 'flex', justifyContent: 'space-between', fontSize: 12.5, color: 'var(--ink-500)' },

  // toast
  toast: { position: 'fixed', bottom: 28, left: '50%', transform: 'translateX(-50%)', display: 'flex', alignItems: 'center', gap: 9, background: 'var(--night-800)', color: 'var(--ink-50)', fontSize: 14, fontWeight: 500, padding: '13px 22px', borderRadius: 'var(--radius-pill)', boxShadow: 'var(--shadow-lg)', zIndex: 100 },
};
