// NFCunnect — Marketing website sections (German)
const { useState } = React;
const S = () => window.wsStyles;

function Wordmark({ light }) {
  return (
    <span style={{ display: 'inline-flex', alignItems: 'baseline', gap: 7 }}>
      <span style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 22, letterSpacing: '-0.01em', color: light ? 'var(--ink-50)' : 'var(--fg)' }}>
        NF<span style={{ color: 'var(--primary)' }}>C</span>unnect
      </span>
    </span>
  );
}

function Nav({ cart, onCart, onCta }) {
  const links = ['Produkt', "So funktioniert's", 'Nachhaltigkeit', 'FAQ'];
  return (
    <nav style={S().nav}>
      <div style={S().navBrand}><Wordmark /></div>
      <div style={S().navLinks}>
        {links.map(l => <button key={l} style={S().navLink} onClick={onCta}>{l}</button>)}
      </div>
      <div style={S().navRight}>
        <button style={S().cartBtn} onClick={onCart} aria-label="Warenkorb">
          <Icon name="briefcase" size={21} />
          {cart > 0 && <span style={S().cartCount}>{cart}</span>}
        </button>
        <button style={S().btnPrimary} onClick={onCta}>Jetzt cunnecten</button>
      </div>
    </nav>
  );
}

function Hero({ onBuy }) {
  return (
    <header style={S().hero}>
      <div>
        <span style={S().overline}>Digitale Visitenkarte</span>
        <h1 style={S().heroH1}>Lass uns <span style={S().heroCu}>cunnecten.</span></h1>
        <p style={S().heroSub}>Einmal antippen, ganze Identität teilen. Der NFCunnect-Schlüsselanhänger aus recyceltem Kupfer ersetzt deine Visitenkarte — ohne App, ohne Papier, ohne Aufwand.</p>
        <div style={S().heroCtas}>
          <button style={S().btnPrimary} onClick={onBuy}>Schlüsselanhänger sichern</button>
          <button style={S().btnSecondary} onClick={onBuy}>So funktioniert's</button>
        </div>
        <div style={S().heroTrust}>
          <span style={S().heroTrustItem}><Icon name="check" size={16} color="var(--copper-600)" /> Wiederbeschreibbar</span>
          <span style={S().heroTrustItem}><Icon name="check" size={16} color="var(--copper-600)" /> Recyceltes Kupfer</span>
          <span style={S().heroTrustItem}><Icon name="check" size={16} color="var(--copper-600)" /> Keine App nötig</span>
        </div>
      </div>
      <div style={S().heroVisual}>
        <img src="../../assets/product-keychain.jpg" style={S().heroImg} alt="NFCunnect Schlüsselanhänger" />
      </div>
    </header>
  );
}

function Problem() {
  const items = [
    'Visitenkarten gehen verloren — oder landen ungelesen im Müll.',
    'QR-Codes wirken unflexibel und lassen sich nicht ändern.',
    'Daten ändern sich. Gedrucktes Papier nicht.',
  ];
  return (
    <section style={{ ...S().section, ...S().problem }}>
      <div style={{ ...S().sectionInner, ...S().problemGrid }}>
        <div>
          <span style={{ ...S().overline, color: 'var(--copper-400)' }}>Das Problem</span>
          <p style={{ ...S().problemQuote, marginTop: 18 }}>Networking ist <span style={S().problemQuoteHl}>umständlich</span> geworden.</p>
        </div>
        <div style={S().problemList}>
          {items.map((t, i) => (
            <div style={S().problemItem} key={i}>
              <span style={S().problemX}><Icon name="x" size={16} color="var(--copper-400)" /></span>
              <span style={S().problemItemText}>{t}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function HowItWorks({ onCta }) {
  const steps = [
    { n: '01', icon: 'nfc', t: 'Antippen', d: 'Halte ein beliebiges Smartphone an den Kupfer-Anhänger. Der NFC-Chip wird sofort erkannt.' },
    { n: '02', icon: 'globe', t: 'Profil öffnet sich', d: 'Deine digitale Visitenkarte erscheint im Browser — Kontakt, Links, Social Media. Ohne App.' },
    { n: '03', icon: 'userplus', t: 'Kontakt speichern', d: 'Ein Tipp speichert dich im Telefonbuch. Du aktualisierst deine Daten jederzeit — der Chip bleibt gleich.' },
  ];
  return (
    <section style={S().section}>
      <div style={S().sectionInner}>
        <span style={S().overline}>So funktioniert's</span>
        <h2 style={{ ...S().h2, marginTop: 14 }}>In drei Sekunden cunnected.</h2>
        <div style={S().steps}>
          {steps.map(s => (
            <div style={S().step} key={s.n}>
              <span style={S().stepNum}>{s.n}</span>
              <div style={S().stepIcon}><Icon name={s.icon} size={24} color="var(--copper-600)" /></div>
              <div style={S().stepTitle}>{s.t}</div>
              <div style={S().stepText}>{s.d}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Sustainability() {
  const stats = [['100%', 'Recyceltes Kupfer'], ['0', 'Blatt Papier'], ['∞', 'Mal neu beschreibbar']];
  return (
    <section style={{ ...S().section, ...S().sustain }}>
      <div style={{ ...S().sectionInner, ...S().sustainGrid }}>
        <div>
          <span style={{ ...S().overline, color: 'var(--copper-700)' }}>Nachhaltigkeit</span>
          <h2 style={{ ...S().h2, marginTop: 14, color: 'var(--ink-900)' }}>Recyceltes Kupfer.<br/>Wiederbeschreibbarer Chip.<br/>Null Papier.</h2>
          <p style={{ fontSize: 16.5, lineHeight: 1.6, color: 'var(--ink-700)', marginTop: 20, maxWidth: '42ch' }}>
            Jeder Anhänger besteht aus hochwertigem, recyceltem Kupfer — langlebig, wertig und wie neu. Statt immer neue Karten zu drucken, überschreibst du einfach deine Daten.
          </p>
        </div>
        <div>
          <div style={S().statRow}>
            {stats.map(([n, l]) => (
              <div style={S().stat} key={l}>
                <div style={S().statNum}>{n}</div>
                <div style={S().statLabel}>{l}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

function Product({ onBuy }) {
  const specs = ['Platte aus recyceltem Kupfer', 'Robuster Metall-Schlüsselring', 'Versiegelter NFC-Chip mit Schutzlack', 'Wiederbeschreibbar & langlebig'];
  return (
    <section style={{ ...S().section, ...S().product }}>
      <div style={{ ...S().sectionInner, ...S().productGrid }}>
        <img src="../../assets/product-keychain.jpg" style={S().productImg} alt="NFCunnect Schlüsselanhänger" />
        <div>
          <span style={S().overline}>Das Produkt</span>
          <h2 style={{ ...S().h2, marginTop: 14 }}>Der NFCunnect-<br/>Schlüsselanhänger.</h2>
          <div style={S().specList}>
            {specs.map(s => (
              <div style={S().spec} key={s}>
                <span style={S().specCheck}><Icon name="check" size={14} color="var(--copper-600)" /></span>{s}
              </div>
            ))}
          </div>
          <div style={S().priceRow}>
            <span style={S().price}>€14,90</span>
            <span style={S().priceNote}>inkl. MwSt.<br/>kostenloser Versand</span>
            <button style={{ ...S().btnPrimary, marginLeft: 'auto', padding: '13px 26px' }} onClick={onBuy}>In den Warenkorb</button>
          </div>
        </div>
      </div>
    </section>
  );
}

function FAQ() {
  const [open, setOpen] = useState(0);
  const qs = [
    ['Brauche ich eine App?', 'Nein. Der NFC-Chip öffnet deine Visitenkarte direkt im Browser des Smartphones — bei iPhone und Android. Weder du noch dein Gegenüber müssen etwas installieren.'],
    ['Kann ich meine Daten später ändern?', 'Ja. Der Chip ist wiederbeschreibbar. Job, Telefonnummer oder Links lassen sich jederzeit aktualisieren — der Anhänger bleibt derselbe.'],
    ['Funktioniert das mit jedem Handy?', 'Nahezu alle modernen Smartphones haben NFC integriert. Beim iPhone wird der Chip automatisch erkannt, bei Android ggf. nach kurzem Antippen.'],
    ['Woraus besteht der Anhänger?', 'Aus einer Platte aus recyceltem Kupfer, einem Metall-Schlüsselring und einem versiegelten NFC-Chip mit Schutzlack — robust und langlebig.'],
  ];
  return (
    <section style={S().section}>
      <div style={S().sectionInner}>
        <span style={{ ...S().overline, display: 'block', textAlign: 'center' }}>FAQ</span>
        <h2 style={{ ...S().h2, marginTop: 14, textAlign: 'center' }}>Häufige Fragen</h2>
        <div style={S().faqList}>
          {qs.map(([q, a], i) => (
            <div style={S().faqItem} key={i}>
              <button style={S().faqQ} onClick={() => setOpen(open === i ? -1 : i)}>
                {q}
                <Icon name="chevron" size={18} color="var(--copper-600)" style={{ transform: open === i ? 'rotate(90deg)' : 'none', transition: 'transform .2s' }} />
              </button>
              {open === i && <div style={S().faqA}>{a}</div>}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer style={S().footer}>
      <div style={S().footerInner}>
        <div>
          <div style={{ marginBottom: 18 }}><Wordmark light /></div>
          <p style={S().footerText}>Wir verbinden Menschen digital — und machen Networking einfacher, moderner und nachhaltiger.</p>
          <div style={S().footerSocials}>
            <button style={S().socialBtn}><Icon name="instagram" size={19} color="var(--copper-400)" /></button>
            <button style={S().socialBtn}><Icon name="tiktok" size={19} color="var(--copper-400)" /></button>
            <button style={S().socialBtn}><Icon name="linkedin" size={19} color="var(--copper-400)" /></button>
          </div>
        </div>
        <div>
          <div style={S().footerColTitle}>Produkt</div>
          <a style={S().footerLink}>Schlüsselanhänger</a>
          <a style={S().footerLink}>So funktioniert's</a>
          <a style={S().footerLink}>Nachhaltigkeit</a>
          <a style={S().footerLink}>FAQ</a>
        </div>
        <div>
          <div style={S().footerColTitle}>Kontakt</div>
          <p style={{ ...S().footerText, maxWidth: '28ch' }}>Hovestraße 50<br/>Innovations- und Ausbildungszentrum<br/>20539 Hamburg</p>
          <a style={{ ...S().footerLink, color: 'var(--copper-400)', marginTop: 10 }}>nfcunnect@outlook.com</a>
        </div>
      </div>
      <div style={S().footerBottom}>
        <span>© 2026 NFCunnect · Juniorfirma</span>
        <span>Let's cunnect.</span>
      </div>
    </footer>
  );
}

Object.assign(window, { Wordmark, Nav, Hero, Problem, HowItWorks, Sustainability, Product, FAQ, Footer });
