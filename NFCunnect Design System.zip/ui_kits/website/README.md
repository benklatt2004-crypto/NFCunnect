# UI Kit — Marketing-Website

Desktop marketing site that sells the NFCunnect copper keychain. German copy, built from the pitch-deck narrative and the CI tone ("kurze, klare Sätze", focus on *verbinden / vernetzen / nachhaltig*).

## Run
Open `index.html`. Scroll the full page. Interactive: the **Warenkorb** counter (every CTA adds an item + toast), and the **FAQ accordion**.

## Sections (`sections.jsx`)
- `Nav` — sticky blurred header, text wordmark, links, cart, "Jetzt cunnecten" CTA.
- `Hero` — "Lass uns **cunnecten.**", subline, dual CTA, trust row, product photo on a warm-black panel.
- `Problem` — dark section: "Networking ist umständlich geworden." + the three pain points from the pitch ("Visitenkarten gehen verloren…").
- `HowItWorks` — 3 steps: Antippen → Profil öffnet sich → Kontakt speichern.
- `Sustainability` — soft-coral gradient, recycled-copper story + stats (100 % / 0 / ∞).
- `Product` — photo, spec list (Kupferplatte, Metallring, versiegelter NFC-Chip…), price €14,90, add-to-cart.
- `FAQ` — accordion (App nötig? Daten ändern? Kompatibilität? Material?).
- `Footer` — dark, wordmark, contact (Hovestraße 50, Hamburg), social (Instagram / TikTok / LinkedIn), "Let's cunnect."
- `Wordmark` — text lockup with copper "C" (used in nav + footer; crisp on light & dark).

Styles in `styles.jsx` (`window.wsStyles`); `Icon.jsx` shared line icons; `app.jsx` wires cart + toasts.

## Brand notes
- Two background worlds in rhythm: warm off-white → dark warm-black (Problem) → soft-coral (Sustainability) → white (Product) → dark (Footer).
- Headlines in Montserrat Alternates, the "cunnect" pun highlighted in copper.
- Warm-tinted shadows; soft 12–28px radii; calm hover/press; no emoji, line icons only.
