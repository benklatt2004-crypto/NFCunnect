// NFCunnect — Marketing website app
const { useState } = React;

function Site() {
  const [cart, setCart] = useState(0);
  const [toast, setToast] = useState('');
  const ping = (m) => { setToast(m); clearTimeout(window.__wt); window.__wt = setTimeout(() => setToast(''), 1800); };
  const buy = () => { setCart(c => c + 1); ping('In den Warenkorb gelegt — Lass uns cunnecten!'); };

  return (
    <div style={window.wsStyles.page}>
      <Nav cart={cart} onCart={() => ping(cart ? `${cart} Artikel im Warenkorb` : 'Dein Warenkorb ist leer')} onCta={buy} />
      <Hero onBuy={buy} />
      <Problem />
      <HowItWorks onCta={buy} />
      <Sustainability />
      <Product onBuy={buy} />
      <FAQ />
      <Footer />
      {toast && <div style={window.wsStyles.toast}><Icon name="check" size={16} color="var(--copper-300)" />{toast}</div>}
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<Site />);
