// NFCunnect — Digital Business Card components
const { useState } = React;

// ---- Tap activation splash (simulates the NFC tap that opens the card) ----
function TapSplash({ onActivate }) {
  const [tapping, setTapping] = useState(false);
  const go = () => { setTapping(true); setTimeout(onActivate, 620); };
  return (
    <div style={dcStyles.splash} onClick={go}>
      <div style={dcStyles.splashWaves}>
        <div style={{ ...dcStyles.orb, ...(tapping ? dcStyles.orbPulse : {}) }}>
          <Icon name="nfc" size={42} color="#fff" />
        </div>
      </div>
      <div style={dcStyles.splashWordmark}>NFCunnect</div>
      <div style={dcStyles.splashTagline}>Zum Cunnecten antippen</div>
      <div style={dcStyles.splashHint}>Halte dein Handy an den Schlüsselanhänger</div>
    </div>
  );
}

// ---- Profile header ----
function ProfileHeader({ profile, onShare }) {
  return (
    <div style={dcStyles.header}>
      <div style={dcStyles.headerBanner}>
        <button style={dcStyles.shareBtn} onClick={onShare} aria-label="Share">
          <Icon name="share" size={18} color="#fff" />
        </button>
      </div>
      <div style={dcStyles.avatarWrap}>
        <div style={dcStyles.avatar}>{profile.initials}</div>
      </div>
      <div style={dcStyles.identity}>
        <div style={dcStyles.name}>{profile.name}</div>
        <div style={dcStyles.role}>{profile.role}</div>
        <div style={dcStyles.company}>
          <Icon name="briefcase" size={14} color="var(--copper-600)" />
          <span>{profile.company}</span>
        </div>
      </div>
    </div>
  );
}

// ---- Save to contacts (primary action) ----
function SaveContactButton({ saved, onSave }) {
  return (
    <button style={{ ...dcStyles.saveBtn, ...(saved ? dcStyles.saveBtnDone : {}) }} onClick={onSave}>
      <Icon name={saved ? 'check' : 'userplus'} size={19} color={saved ? 'var(--copper-600)' : '#fff'} />
      <span>{saved ? 'In Kontakten gespeichert' : 'Zu Kontakten hinzufügen'}</span>
    </button>
  );
}

// ---- A single link / detail row ----
function LinkRow({ icon, label, value, onClick }) {
  return (
    <button style={dcStyles.row} onClick={onClick}
      onMouseDown={e => e.currentTarget.style.transform = 'scale(0.985)'}
      onMouseUp={e => e.currentTarget.style.transform = 'scale(1)'}
      onMouseLeave={e => e.currentTarget.style.transform = 'scale(1)'}>
      <span style={dcStyles.rowIcon}><Icon name={icon} size={18} color="var(--copper-600)" /></span>
      <span style={dcStyles.rowText}>
        <span style={dcStyles.rowLabel}>{label}</span>
        <span style={dcStyles.rowValue}>{value}</span>
      </span>
      <Icon name="chevron" size={16} color="var(--ink-400)" />
    </button>
  );
}

function LinkList({ children, title }) {
  return (
    <div style={dcStyles.list}>
      {title && <div style={dcStyles.listTitle}>{title}</div>}
      <div style={dcStyles.listRows}>{children}</div>
    </div>
  );
}

// ---- Share sheet (bottom sheet) ----
function ShareSheet({ open, onClose, profile }) {
  const [copied, setCopied] = useState(false);
  if (!open) return null;
  const url = 'nfcunnect.de/' + profile.handle;
  return (
    <div style={dcStyles.scrim} onClick={onClose}>
      <div style={dcStyles.sheet} onClick={e => e.stopPropagation()}>
        <div style={dcStyles.sheetGrab} />
        <div style={dcStyles.sheetTitle}>Karte teilen</div>
        <div style={dcStyles.qrRow}>
          <div style={dcStyles.qr}>
            <Icon name="nfc" size={30} color="var(--copper-600)" />
          </div>
          <div>
            <div style={dcStyles.qrName}>{profile.name}</div>
            <div style={dcStyles.qrUrl}>{url}</div>
          </div>
        </div>
        <button style={dcStyles.copyBtn} onClick={() => { setCopied(true); setTimeout(() => setCopied(false), 1600); }}>
          <Icon name={copied ? 'check' : 'copy'} size={17} color="var(--copper-600)" />
          <span>{copied ? 'Link kopiert' : 'Link kopieren'}</span>
        </button>
        <button style={dcStyles.sheetClose} onClick={onClose}>Schließen</button>
      </div>
    </div>
  );
}

// ---- Toast ----
function Toast({ msg }) {
  if (!msg) return null;
  return <div style={dcStyles.toast}><Icon name="check" size={15} color="var(--copper-300)" /><span>{msg}</span></div>;
}

// ---- Footer ----
function CardFooter() {
  return (
    <div style={dcStyles.footer}>
      <div style={dcStyles.footerMark}>NFCunnect</div>
      <div style={dcStyles.footerTag}>Let's cunnect · digitale Visitenkarte</div>
    </div>
  );
}

Object.assign(window, { TapSplash, ProfileHeader, SaveContactButton, LinkRow, LinkList, ShareSheet, Toast, CardFooter });
