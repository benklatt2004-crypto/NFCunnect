// NFCunnect — Digital Business Card styles. Assigned to window.dcStyles.
window.dcStyles = {
  // ---- Tap splash ----
  splash: {
    position: 'absolute', inset: 0, background: 'radial-gradient(120% 80% at 50% 30%, #2A1812 0%, #100A07 70%)',
    display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
    gap: 0, cursor: 'pointer', userSelect: 'none', zIndex: 20,
  },
  splashWaves: { marginBottom: 28, position: 'relative' },
  orb: {
    width: 96, height: 96, borderRadius: '50%',
    background: 'radial-gradient(circle at 50% 38%, #F2832A, #C45F12)',
    boxShadow: '0 0 0 0 rgba(224,116,26,.5), var(--glow-copper)',
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    transition: 'all .6s cubic-bezier(.22,1,.36,1)',
  },
  orbPulse: { transform: 'scale(1.35)', boxShadow: '0 0 0 40px rgba(224,116,26,0), 0 0 60px rgba(224,116,26,.7)', opacity: 0 },
  splashWordmark: { fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 28, color: 'var(--ink-50)', letterSpacing: '-0.01em' },
  splashTagline: { fontFamily: 'var(--font-sans)', fontWeight: 600, fontSize: 13, letterSpacing: '0.22em', textTransform: 'uppercase', color: 'var(--copper-400)', marginTop: 8 },
  splashHint: { fontSize: 12.5, color: 'var(--d-fg-muted)', marginTop: 22 },

  // ---- Header ----
  header: { position: 'relative', background: 'var(--surface)' },
  headerBanner: { height: 132, background: 'linear-gradient(135deg, #F0926B 0%, #E0741A 55%, #C45F12 100%)', position: 'relative' },
  shareBtn: { position: 'absolute', top: 16, right: 16, width: 38, height: 38, borderRadius: '50%', border: 'none', background: 'rgba(16,10,7,0.22)', backdropFilter: 'blur(6px)', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' },
  avatarWrap: { display: 'flex', justifyContent: 'center', marginTop: -46 },
  avatar: {
    width: 92, height: 92, borderRadius: '50%', background: 'var(--night-800)', color: '#fff',
    border: '4px solid var(--surface)', display: 'flex', alignItems: 'center', justifyContent: 'center',
    fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 32, boxShadow: 'var(--shadow-md)',
  },
  identity: { textAlign: 'center', padding: '12px 24px 4px' },
  name: { fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 24, color: 'var(--fg)', letterSpacing: '-0.01em' },
  role: { fontSize: 14.5, color: 'var(--fg-muted)', marginTop: 3 },
  company: { display: 'inline-flex', alignItems: 'center', gap: 6, marginTop: 10, fontSize: 13, fontWeight: 600, color: 'var(--copper-700)', background: 'var(--copper-50)', padding: '5px 12px', borderRadius: 'var(--radius-pill)' },

  // ---- Save button ----
  saveBtn: {
    display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 9, width: '100%',
    margin: '18px 0 4px', padding: '14px', border: 'none', borderRadius: 'var(--radius-md)',
    background: 'var(--primary)', color: '#fff', fontFamily: 'var(--font-sans)', fontWeight: 600,
    fontSize: 15, cursor: 'pointer', boxShadow: 'var(--shadow-sm)', transition: 'all .16s cubic-bezier(.22,1,.36,1)',
  },
  saveBtnDone: { background: 'var(--copper-50)', color: 'var(--copper-700)', boxShadow: 'none' },

  // ---- Link rows ----
  list: { marginTop: 18 },
  listTitle: { fontSize: 11, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.14em', color: 'var(--fg-subtle)', marginBottom: 10, paddingLeft: 2 },
  listRows: { display: 'flex', flexDirection: 'column', gap: 9 },
  row: {
    display: 'flex', alignItems: 'center', gap: 13, width: '100%', textAlign: 'left',
    padding: '13px 15px', background: 'var(--surface)', border: '1px solid var(--border)',
    borderRadius: 'var(--radius-md)', cursor: 'pointer', boxShadow: 'var(--shadow-xs)',
    transition: 'transform .09s ease, box-shadow .16s ease', fontFamily: 'var(--font-sans)',
  },
  rowIcon: { width: 38, height: 38, borderRadius: 10, background: 'var(--copper-50)', display: 'flex', alignItems: 'center', justifyContent: 'center', flex: 'none' },
  rowText: { display: 'flex', flexDirection: 'column', flex: 1, minWidth: 0 },
  rowLabel: { fontSize: 11, color: 'var(--fg-subtle)', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.06em' },
  rowValue: { fontSize: 14.5, color: 'var(--fg)', fontWeight: 500, marginTop: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' },

  // ---- Share sheet ----
  scrim: { position: 'absolute', inset: 0, background: 'rgba(16,10,7,0.55)', display: 'flex', alignItems: 'flex-end', zIndex: 30, animation: 'dcFade .2s ease' },
  sheet: { width: '100%', background: 'var(--surface)', borderRadius: '22px 22px 0 0', padding: '12px 22px 26px', animation: 'dcSlide .26s cubic-bezier(.22,1,.36,1)' },
  sheetGrab: { width: 40, height: 4, borderRadius: 2, background: 'var(--ink-300)', margin: '0 auto 16px' },
  sheetTitle: { fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 18, color: 'var(--fg)', marginBottom: 16 },
  qrRow: { display: 'flex', alignItems: 'center', gap: 14, padding: '14px', background: 'var(--ink-50)', borderRadius: 'var(--radius-md)', border: '1px solid var(--border)' },
  qr: { width: 56, height: 56, borderRadius: 12, background: 'var(--copper-50)', display: 'flex', alignItems: 'center', justifyContent: 'center', flex: 'none' },
  qrName: { fontWeight: 700, fontSize: 15, color: 'var(--fg)' },
  qrUrl: { fontFamily: 'var(--font-mono)', fontSize: 12.5, color: 'var(--copper-600)', marginTop: 2 },
  copyBtn: { display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8, width: '100%', marginTop: 12, padding: '13px', border: '1.5px solid var(--copper-300)', borderRadius: 'var(--radius-md)', background: 'var(--surface)', color: 'var(--copper-700)', fontFamily: 'var(--font-sans)', fontWeight: 600, fontSize: 14, cursor: 'pointer' },
  sheetClose: { display: 'block', width: '100%', marginTop: 10, padding: '12px', border: 'none', background: 'transparent', color: 'var(--fg-muted)', fontFamily: 'var(--font-sans)', fontWeight: 600, fontSize: 14, cursor: 'pointer' },

  // ---- Toast ----
  toast: { position: 'absolute', bottom: 24, left: '50%', transform: 'translateX(-50%)', display: 'flex', alignItems: 'center', gap: 8, background: 'var(--night-800)', color: 'var(--ink-50)', fontSize: 13.5, fontWeight: 500, padding: '11px 18px', borderRadius: 'var(--radius-pill)', boxShadow: 'var(--shadow-lg)', zIndex: 40, animation: 'dcToast .25s ease' },

  // ---- Footer ----
  footer: { textAlign: 'center', marginTop: 26, paddingTop: 18, borderTop: '1px solid var(--border)' },
  footerMark: { fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 15, color: 'var(--fg)' },
  footerTag: { fontSize: 11, letterSpacing: '0.14em', textTransform: 'uppercase', color: 'var(--copper-600)', marginTop: 4, fontWeight: 600 },
};
