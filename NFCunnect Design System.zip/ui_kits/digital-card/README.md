# UI Kit — Digitale Visitenkarte (NFC)

The mobile page the NFCunnect chip opens when a phone taps the keychain. This *is* the product's payload: a re-writable digital identity / business card. German UI.

## Run
Open `index.html`. The screen starts on the **NFC-Tap-Splash** (warm near-black + glowing copper mark). Tap anywhere to simulate the NFC tap → the card slides in. "↺ Tippen wiederholen" replays the flow.

## Flow
1. **TapSplash** — "Zum Cunnecten antippen" / "Halte dein Handy an den Schlüsselanhänger". Tap → copper-glow pulse → card.
2. **Card** — copper gradient banner, avatar, name/role/company, **Zu Kontakten hinzufügen** (primary), link list (Mobil, E-Mail, LinkedIn, Instagram, Website, Büro), footer.
3. **Teilen** — bottom share sheet with copy-link.
4. **Toasts** confirm each action.

## Components (`components.jsx`)
- `TapSplash` — NFC activation screen.
- `ProfileHeader` — banner + avatar + identity + share button.
- `SaveContactButton` — primary save-to-contacts (toggles to "gespeichert").
- `LinkRow` / `LinkList` — tappable detail rows with copper icon chips.
- `ShareSheet` — bottom sheet with copy-link.
- `Toast`, `CardFooter`.
- `Icon` (`Icon.jsx`) — self-contained Lucide-style line icons.

Styles live in `styles.jsx` (`window.dcStyles`); the phone shell + demo data in `app.jsx`.

## Brand notes
- Warm near-black splash + copper glow = the brand's signature "lit logo on black" moment.
- All surfaces use the warm neutral ramp; icons are copper-on-copper-tint chips.
- No emoji; line icons only. Calm motion (slide/fade, no bounce).

> Grounded in NFCunnect's "digitale Visitenkarte / digital identity / smart networking" corporate language and the internal Linktree how-to. The brand has no shipping app code yet — this is an evidence-based recreation of the intended product surface.
