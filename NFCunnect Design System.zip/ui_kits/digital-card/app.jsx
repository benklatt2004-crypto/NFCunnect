// NFCunnect — Digital Business Card demo flow
const { useState } = React;

const PROFILE = {
  name: 'Jamie Becker',
  initials: 'JB',
  role: 'Vertrieb & Partnerschaften',
  company: 'Aurubis AG',
  handle: 'jamie',
  links: [
    { icon: 'phone', label: 'Mobil', value: '+49 151 234 567', toast: 'Jamie wird angerufen…' },
    { icon: 'mail', label: 'E-Mail', value: 'jamie.becker@aurubis.com', toast: 'E-Mail wird geöffnet…' },
    { icon: 'linkedin', label: 'LinkedIn', value: 'in/jamie-becker', toast: 'LinkedIn wird geöffnet…' },
    { icon: 'instagram', label: 'Instagram', value: '@jamie.cunnect', toast: 'Instagram wird geöffnet…' },
    { icon: 'globe', label: 'Website', value: 'nfcunnect.de', toast: 'Website wird geöffnet…' },
    { icon: 'mappin', label: 'Büro', value: 'Hovestraße 50, Hamburg', toast: 'Karte wird geöffnet…' },
  ],
};

function App() {
  const [activated, setActivated] = useState(false);
  const [saved, setSaved] = useState(false);
  const [share, setShare] = useState(false);
  const [toast, setToast] = useState('');

  const ping = (msg) => { setToast(msg); clearTimeout(window.__t); window.__t = setTimeout(() => setToast(''), 1700); };

  return (
    <div style={shellStyles.phone}>
      <div style={shellStyles.screen}>
        {!activated && <TapSplash onActivate={() => setActivated(true)} />}
        {activated && (
          <div style={shellStyles.scroll}>
            <ProfileHeader profile={PROFILE} onShare={() => setShare(true)} />
            <div style={shellStyles.pad}>
              <SaveContactButton saved={saved} onSave={() => { setSaved(true); ping('Kontakt gespeichert'); }} />
              <LinkList title="Kontakt aufnehmen">
                {PROFILE.links.map((l, i) => (
                  <LinkRow key={i} icon={l.icon} label={l.label} value={l.value} onClick={() => ping(l.toast)} />
                ))}
              </LinkList>
              <CardFooter />
            </div>
          </div>
        )}
        <ShareSheet open={share} onClose={() => setShare(false)} profile={PROFILE} />
        <Toast msg={toast} />
      </div>
      {activated && (
        <button style={shellStyles.replay} onClick={() => { setActivated(false); setSaved(false); setShare(false); }}>
          ↺ Tippen wiederholen
        </button>
      )}
    </div>
  );
}

window.shellStyles = {
  phone: { display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 16 },
  screen: {
    position: 'relative', width: 390, height: 780, background: 'var(--surface)',
    borderRadius: 44, overflow: 'hidden', boxShadow: '0 40px 90px -30px rgba(74,36,6,0.45), 0 0 0 11px #14100D, 0 0 0 13px #2A1812',
  },
  scroll: { position: 'absolute', inset: 0, overflowY: 'auto' },
  pad: { padding: '0 22px 30px' },
  replay: { border: '1px solid var(--border)', background: 'var(--surface)', color: 'var(--fg-muted)', fontFamily: 'var(--font-sans)', fontWeight: 600, fontSize: 13, padding: '9px 18px', borderRadius: 'var(--radius-pill)', cursor: 'pointer', boxShadow: 'var(--shadow-xs)' },
};

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
