# NFCunnect — Design System

> **Let's cunnect!** — durable copper keychains with a programmable NFC chip that work as a digital business card.

NFCunnect is a German **Juniorfirma** (student/apprentice-run company) based at the Innovations- und Ausbildungszentrum of **Aurubis AG**, the Hamburg copper group. The team designs, programs and sells a **coated keychain made of durable recycled copper with a sealed NFC chip**. Tap it with a phone and it opens a digital identity — a business card, emergency contact card, even a dog microchip-style ID. The data can be re-written and updated forever, so nothing is ever printed or thrown away.

The brand sits at the intersection of **technology and sustainability**: futuristic, clean networking on the one hand; warm, tactile, recycled copper on the other. That tension — cool tech, warm material — is the heart of the visual language.

- **Vision:** Redefine networking — digital and sustainable.
- **Mission:** Create products that connect people in everyday life, through digitalization and material quality.
- **Core messages:** "We connect people digitally." · "We make networking simpler, more modern, and more sustainable."
- **Values:** Connection · Simplicity · Quality · Sustainability.
- **Location:** Hovestraße 50, Innovations- und Ausbildungszentrum, 20539 Hamburg · nfcunnect@outlook.com
- **Channels:** Website, Instagram, TikTok, LinkedIn (`@nfcunnect`).

## The product

A small rectangular **copper plate** on a metal keyring, with a **sealed, coated NFC chip** on a black label. The chip is programmable and re-writable. Positioning is *premium / differentiation, not cost leadership*: high-quality copper, reputable for business users, like-new condition, versatile, long service life.

**The problem it solves (brand copy):** *"Business cards get lost. QR codes seem inflexible. Data changes, but printed materials don't. Many people are looking for a simple, sustainable, and smart way to share important information: no apps, no paper, no hassle."*

**Target audience:** business professionals, Gen Y & Z, tech-savvy users (smart-home / smartphone owners).

---

## Products represented in this system

There is **no shipping web/app codebase** in the source material — the company is early-stage and the digital surfaces are *planned* (the pitch deck lists "Creation of an online store" as a future goal, and there are internal guides for building a Linktree-style page the chip points to). The two UI kits here are therefore **faithful, evidence-grounded recreations** of the two digital surfaces the brand clearly implies:

1. **Marketing website** (`ui_kits/website/`) — desktop site that sells the keychain: hero, the problem, how-it-works, sustainability, product, FAQ, footer. Built from the pitch-deck narrative and CI tone.
2. **Digital business card** (`ui_kits/digital-card/`) — the mobile profile page the NFC chip opens when tapped. This *is* the product's payload: avatar, name/role, save-to-contacts, link list, share. Grounded in the "digitale business card / Linktree" guides and the "digital identity / smart networking" corporate language.

---

## Sources (for the reader)

These were the inputs used to build this system. You may not have access; they are recorded for provenance.

- **GitHub:** [`benklatt2004-crypto/NFCunnect`](https://github.com/benklatt2004-crypto/NFCunnect) — Corporate Identity PDF, logo (`NFCunnect Logo v2 trans.png`), product photo (`Produktbild.jpg`), README. *Explore this repo for the canonical CI and brand assets.*
- **Local codebase folder** `Allgemeines/` — the Juniorfirma's working drive: Corporate Identity PDF, English pitch deck (`Pitch-Deck/NFCunnect Pitch Englisch.pdf`/`.pptx`), company presentations, the roll-up banner (`Messestand/NFCunnect.png`), and the "Anleitung Linktree erstellen" / "NFC-Chip Programmierung" how-to guides.
- Copies of the key source files are archived in `sources/` in this project.

> To build higher-fidelity NFCunnect designs, explore the GitHub repo above — it holds the authoritative CI document and logo files.

---

## CONTENT FUNDAMENTALS — how NFCunnect writes

The voice is **clear, confident, and warm-technical**. Technology is always explained plainly; sustainability is a quiet point of pride, never preachy.

- **Sentences are short and clear.** The CI mandates "kurze, klare Sätze" — explain technology understandably. No jargon walls.
- **Person & address:** Speaks as **"we"** (the company) and addresses the reader directly. German marketing uses the friendly, energetic register ("Lass uns cunnecten!"). English material is plain and professional ("Let's cunnect", "no apps, no paper, no hassle").
- **The "cunnect" pun is the brand's signature.** The `o` in connect is dropped to echo **NFC**: *cunnect, cunnected, connection, Let's cunnect*. Use it in taglines and headlines — but keep functional/body copy in normal spelling so instructions stay clear.
- **Three verbs do the heavy lifting:** *connect / network / digitalize* (verbinden, vernetzen, digitalisieren). Most headlines orbit one of them.
- **Signature vocabulary (Corporate Language):** "Let's cunnect", "digital identity", "smart networking", "digitale business card", "no apps, no paper, no hassle".
- **Casing:** Display headlines are often **ALL CAPS** and bold (banner: "LASS UNS CUNNECTEN!", "MEHR INFOS AUF SOCIAL MEDIA"). The wordmark lockup pairs title-case "NFCunnect" with a tracked uppercase tagline "LET'S CUNNECT". Body copy is sentence case.
- **Emoji:** **Not used** in brand/marketing material. Keep interfaces emoji-free; use line icons instead.
- **Tone words:** trustworthy, serious, transparent, modern, sustainable. Avoid hype, avoid exclamation overload (the one allowed exclamation is "Let's cunnect!").
- **Examples to model:**
  - Hero: *"Let's cunnect. One tap. Your whole identity."*
  - Value prop: *"Business cards get lost. Yours never will."*
  - Sustainability: *"Recycled copper. Re-writable chip. Zero paper."*
  - CTA: *"Tap to cunnect"*, *"Get your keychain"*.

---

## VISUAL FOUNDATIONS

**Overall feel:** warm, premium, tactile-tech. Copper is the hero — it stands for both the literal product material and the recycled-sustainability story. Backgrounds split into two worlds: **light & warm** (off-white / soft coral) for marketing, and **deep warm-black with a glowing copper mark** for the product/"card" moments (see the printed business cards: copper logo glowing on near-black).

### Color
- **Primary is copper `#E0741A`** (sampled directly from the logo strokes) with a full ramp `--copper-50…900`. It is the single dominant brand color — per CI, "Kupfer / Orange als Hauptfarbe."
- **Ember `#E15A33`** is the deeper red-orange used for big headlines on coral backgrounds; **soft coral `#F0926B`** is the warm tinted background seen on the roll-up banner.
- **Neutrals are warm**, never pure gray — an ink ramp biased toward brown (`--ink-900 #14100D` text → `--ink-50 #FAF6F2` page). Pure `#000`/`#888` look wrong here.
- **Dark surfaces are warm near-black** (`--night-800 #1A0E0A`), used with a **copper glow** (`--glow-copper`) to recreate the lit-logo business-card look.
- Status colors lean warm but stay legible. Full tokens in `colors_and_type.css`.

### Type
- **Display / headings: Montserrat Alternates** (mandated by CI for the wordmark — its rounded geometric `a`/`t` give the futuristic feel). Bold/Semibold, tight tracking, often ALL CAPS for big statements.
- **UI / body: Montserrat** — clean, geometric, highly legible.
- **Technical / NFC IDs: Space Mono** — for chip IDs, code, tap-counters; reinforces the "smart" tech angle.
- **Overline lockup:** semibold, uppercase, wide tracking (`0.18em`) — the recurring "LET'S CUNNECT" treatment.
- Scale: 1.250 major-third, 16px base. See semantic classes (`.display`, `h1–h4`, `.lead`, `.overline`, `.mono`).

### Backgrounds
- Light marketing: warm off-white `--ink-50`, occasionally a **soft coral wash** or a copper→ember gradient used *sparingly* as an accent panel (not full-page noise).
- Dark/product: warm near-black with a subtle radial copper glow behind the mark. No photographic noise/grain in the digital brand, though the physical copper has a lovely natural patina (see product photo) — lean on real product imagery rather than faking texture.
- The **spirograph line-mark** itself can be used oversized and low-contrast as a decorative background motif (as on the banner).

### Spacing, radii, borders
- 4px spacing base (`--space-1…9`).
- **Radii are soft-modern:** cards/panels `--radius-lg 18px`, buttons `--radius-md 12px`, pills `999px`. Mirrors the rounded corners of the physical keychain plate. Avoid sharp 0px corners and avoid huge 40px+ blobs.
- **Borders:** hairline warm `--ink-200` on light; on dark, a translucent copper border `--d-border rgba(224,116,26,.22)`.

### Shadows & elevation
- **Warm-tinted shadows**, never neutral black: `--shadow-sm/md/lg` are built on `rgba(74,36,6,…)`. Soft and diffuse.
- On dark surfaces, elevation is expressed as a **copper glow** rather than a drop shadow.
- Cards = white surface + warm border + `--shadow-sm`, lifting to `--shadow-md` on hover.

### Motion, hover & press
- **Calm, purposeful motion.** Ease `cubic-bezier(0.22,1,0.36,1)` (gentle ease-out), 160–240ms. Fades and small lifts; **no bounces, no springy overshoot** — the brand is "serious, trustworthy."
- **Hover:** primary buttons darken one step (`--primary` → `--primary-hover`); cards lift (translateY -2px) and deepen shadow; links shift to copper.
- **Press:** subtle scale-down (`0.98`) and step to `--primary-press`. Quick (90ms).
- Signature flourish: a one-shot **copper glow pulse** on the NFC "tap" interaction — used rarely, only on the card-activation moment.

### Transparency & blur
- Used lightly: sticky headers get a `backdrop-filter: blur(10px)` over a translucent off-white/near-black. Overlays use a warm dark scrim `rgba(16,10,7,.55)`. Avoid heavy glassmorphism.

### Imagery
- Real **product photography** of the copper keychain — warm, slightly burnished, natural light. The copper reads peach-to-amber. Keep imagery warm; never cool/blue-tinted, never B&W.
- The spirograph mark is the only "illustration"; do not invent new illustrations or icons in the brand's decorative style.

---

## ICONOGRAPHY

NFCunnect has **no proprietary icon font or custom icon set** in the source material. Iconography should be **functional, single-weight line icons** that match Montserrat's clean geometry.

- **Recommended set: [Lucide](https://lucide.dev)** (CDN) — 1.5–2px stroke, rounded joins. It matches the brand's geometric-but-warm feel and the rounded logo letterforms. *This is a substitution* (no original set existed); flagged here for the user.
- Stroke icons only — **no filled/duotone icon styles**, no emoji, no unicode-glyph icons in UI.
- Recommended icon stroke color: `currentColor`, usually `--fg-muted` at rest and `--primary` when active/selected.
- Social channels use their **official brand marks** (Instagram, TikTok, LinkedIn) — see the banner; do not restyle them.
- **The brand mark itself** is the spirograph/"woven copper ring" symbol — supplied as a raster PNG (`assets/logo-*.png`), *not* an SVG. Treat it as an image asset; never redraw it by hand. Available lockups:
  - `assets/logo-mark-wordmark.png` — mark + "NFCunnect / LET'S CUNNECT" wordmark on transparent (primary lockup).
  - `assets/logo-original.png` — square logo.
  - `assets/messestand-banner.png` — roll-up banner, shows the coral palette + social lockup in use.
- `assets/product-keychain.jpg` — real product photo (copper keychains on a stand).

---

## Index — what's in this system

| File / folder | What it is |
|---|---|
| `README.md` | This file — brand context, content & visual foundations, iconography, index. |
| `colors_and_type.css` | Source-of-truth design tokens: color ramps, semantic colors, type scale + classes, spacing, radii, shadows. Import this into any design. |
| `SKILL.md` | Agent-Skills front-matter so this system can be used directly in Claude Code. |
| `assets/` | Logos, banner, and product photography. Copy what you need into a design. |
| `sources/` | Archived source documents (CI PDF, pitch deck PDF, original logo). |
| `preview/` | Small HTML cards that populate the Design System tab (colors, type, spacing, components). |
| `ui_kits/website/` | Marketing-website UI kit — `index.html` + JSX components + README. |
| `ui_kits/digital-card/` | Digital-business-card (NFC tap target) UI kit — `index.html` + JSX components + README. |

### Font substitutions (flagged)
- **Montserrat Alternates** and **Montserrat** are the CI-specified fonts and are loaded from **Google Fonts** (not bundled as local files). **Space Mono** (technical/mono) and the **Lucide** icon set are *additions/substitutions* chosen to fit the brand — no original mono font or icon set existed in the source. Let me know if you'd like different choices or self-hosted font files.
